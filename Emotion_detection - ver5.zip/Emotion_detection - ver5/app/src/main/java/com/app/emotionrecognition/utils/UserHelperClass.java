package com.app.emotionrecognition.utils;


public class UserHelperClass {
   public String fname,lname, email, password, age, gender;

    public UserHelperClass(String fname, String lname, String email, String pass, String age, String gender)
    {
        this.fname=fname;
        this.lname=lname;
        this.email=email;
        this.password=pass;
        this.age=age;
        this.gender=gender;


    }

//
//    public UserHelperClass(String fullname, String email, String password, String age, String gender) {
//        this.fullname = fullname;
//        this.email = email;
//        this.password = password;
//        this.age = age;
//        this.gender = gender;
//    }


}