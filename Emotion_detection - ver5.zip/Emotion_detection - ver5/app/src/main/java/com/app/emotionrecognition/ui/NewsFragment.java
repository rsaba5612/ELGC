package com.app.emotionrecognition.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.app.emotionrecognition.databinding.FragmentNewsBinding;


public class NewsFragment extends Fragment {

    private FragmentNewsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentNewsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        // loading http://www.google.com url in the the WebView.
        binding.web.loadUrl("https://www.cdc.gov/ncbddd/autism/index.html");

        // this will enable the javascript.
        binding.web.getSettings().setJavaScriptEnabled(true);

        // WebViewClient allows you to handle
        // onPageFinished and override Url loading.
        binding.web.setWebViewClient(new WebViewClient());


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}