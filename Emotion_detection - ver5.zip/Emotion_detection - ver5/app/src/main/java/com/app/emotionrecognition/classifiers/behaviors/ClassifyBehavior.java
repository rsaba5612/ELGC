package com.app.emotionrecognition.classifiers.behaviors;

public interface ClassifyBehavior {
    float[][] classify(float[] input);
}
