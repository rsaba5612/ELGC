package com.app.emotionrecognition.database;

import com.google.gson.annotations.SerializedName;

public class DataModel {
    @SerializedName("status")
    private int status;
    @SerializedName("message")
    private int message;

    public DataModel(int status, int message) {
        this.status = status;
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getMessage() {
        return message;
    }

    public void setMessage(int message) {
        this.message = message;
    }
}
