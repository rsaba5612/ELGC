package com.app.emotionrecognition.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;


import com.app.emotionrecognition.R;

public class firstname extends AppCompatActivity {
    boolean doubleBackToExitPressedOnce = false;

    private Button usernextbtn;
    EditText firstname, lastname;

    private ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstname);
        firstname=(EditText)findViewById(R.id.firstname);
        lastname=(EditText)findViewById(R.id.lastname);
        imgbtn=(ImageButton) findViewById(R.id.btn_back);





        usernextbtn=findViewById(R.id.usernextbtn);
        usernextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fname=firstname.getText().toString().trim();
                String lname=lastname.getText().toString().trim();


                    Intent main = new Intent(firstname.this, email.class);
                    main.putExtra("firstname", fname);
                    main.putExtra("lastname", lname);
                    startActivity(main);
                    overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);

                    finish();


            }
        });
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),login.class);
                startActivity(intent);
                finish();

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(firstname.this, login.class);
        startActivity(main);
        finish();

    }
}