package com.app.emotionrecognition.database;


public class ScoreItem {

    public String name, result, date, correctAnswers, secondsCounter;
}
