package com.app.emotionrecognition.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;


import com.app.emotionrecognition.R;

public class email extends AppCompatActivity {

    String firstname,lastname;
    EditText username, password;
    private Button agenextbtn;

    private ImageButton imgbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        username=(EditText)findViewById(R.id.textemail);
        password=(EditText)findViewById(R.id.password);
        agenextbtn=findViewById(R.id.agenextbtn);
        imgbtn=(ImageButton) findViewById(R.id.btn_back);







        Intent i=getIntent();
        firstname=i.getStringExtra("firstname");
        lastname=i.getStringExtra("lastname");


        agenextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Email=username.getText().toString().trim();
                String pass=password.getText().toString().trim();
                String fname=firstname;
                String lname=lastname;
//
//                if (Email.isEmpty()) {
//                    email.setError(getString(R.string.input_error_email));
//                    email.requestFocus();
//                    progressDialog.dismiss();
//                    return;
//                }
//                if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
//                    email.setError(getString(R.string.input_error_email_invalid));
//                    email.requestFocus();
//                    progressDialog.dismiss();
//                    return;
//                }


                    Intent main = new Intent(email.this, register.class);
                    main.putExtra("firstname", fname);
                    main.putExtra("lastname", lname);
                    main.putExtra("email", Email);
                    main.putExtra("password", pass);
                    startActivity(main);
                    overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);

                    finish();




            }
        });
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),firstname.class);
                startActivity(intent);
                finish();

            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(email.this, firstname.class);
        startActivity(main);
        finish();

    }
}