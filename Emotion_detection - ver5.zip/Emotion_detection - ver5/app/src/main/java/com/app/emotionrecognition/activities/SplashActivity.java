package com.app.emotionrecognition.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.app.emotionrecognition.R;
import com.app.emotionrecognition.databinding.SplashActivityBinding;
import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {
    Animation topAnim , bottomAnim;
    private FirebaseAuth firebaseAuth;

    private SplashActivityBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=SplashActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FirebaseApp.initializeApp(this);
        //setup Animation
        topAnim= AnimationUtils.loadAnimation(this , R.anim.top_anim);
        bottomAnim= AnimationUtils.loadAnimation(this , R.anim.bottom_anim);

        firebaseAuth=FirebaseAuth.getInstance();
        binding.logo.setAnimation(topAnim);
        binding.tvAppName.setAnimation(bottomAnim);


        new Handler().postDelayed(() -> {
            if(firebaseAuth.getCurrentUser() != null )
            {
                finish();
                startActivity(new Intent(this,HomeActivity.class ));
            }
            else
            {
                startActivity(new Intent(SplashActivity.this, login.class));
                finish();

            }




        }, 1000);
    }
    }
