package com.app.emotionrecognition.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.app.emotionrecognition.R;
import com.app.emotionrecognition.utils.UserHelperClass;

public class register extends AppCompatActivity {

    boolean doubleBackToExitPressedOnce = false;
    String Gender="";
    Button signup;
    EditText age;
    RadioGroup gendergrp;
    RadioButton male,female;
    private TextView textlogin;
    String firstname, lastname, email, password;
    //    ProgressBar loading;

    private ImageButton imgbtn;



    private FirebaseAuth mAuth;
    DatabaseReference ref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        signup = (Button) findViewById(R.id.signup);
//        loading=findViewById(R.id.progress);
        age = (EditText) findViewById(R.id.age);
        gendergrp = (RadioGroup) findViewById(R.id.gender);
        male=findViewById(R.id.malebtn);
        female=findViewById(R.id.femalebtn);
        textlogin = findViewById(R.id.textlogin);


        ref = FirebaseDatabase.getInstance().getReference("Users");
        mAuth = FirebaseAuth.getInstance();


//        AW.addValidation(this,R.id.gender,  RegexTemplate.NOT_EMPTY,R.string.invalid_gender);
        Intent i = getIntent();
        firstname = i.getStringExtra("firstname");
        lastname = i.getStringExtra("lastname");
        email = i.getStringExtra("email");
        password = i.getStringExtra("password");

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Register();
            }
        });

        textlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent=new Intent(getApplicationContext(),login.class);
                startActivity(intent);
            }
        });

        imgbtn=(ImageButton) findViewById(R.id.btn_back);

        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),email.class);
                startActivity(intent);
                finish();

            }
        });

    }

    public void Register() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait..");





            if (gendergrp.getCheckedRadioButtonId() == -1) {
                Toast.makeText(getApplicationContext(), "Please select Gender", Toast.LENGTH_SHORT).show();
            } else {


//                // get selected radio button from radioGroup
//                int selectedId = gendergrp.getCheckedRadioButtonId();
//                // find the radiobutton by returned id
//                genderbtn = (RadioButton) findViewById(selectedId);
//                final String gendervalue = genderbtn.getText().toString();

                progressDialog.show();
                final String fname = firstname;
                final String lname = lastname;
                final String Email = email;
                final String pass = password;
                final String Age = this.age.getText().toString().trim();
                if(male.isChecked()){
                    Gender="Male";

                }else if(female.isChecked())
                {
                    Gender="Female";
                }
                mAuth.createUserWithEmailAndPassword(Email, pass)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                progressDialog.dismiss();

                                if (task.isSuccessful()) {
                                    UserHelperClass user = new UserHelperClass(
                                            fname,
                                            lname,
                                            Email,
                                            pass,
                                            Age,
                                            Gender
                                    );
                                    ref.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                            .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            progressDialog.dismiss();
                                            if (task.isSuccessful()) {
                                                mAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful())
                                                        {
//                                                    finish();
                                                            Toast.makeText(register.this, "Registration Successfully...!! Please check your Email for verification", Toast.LENGTH_LONG).show();
                                                            Intent main = new Intent(register.this, login.class);
                                                            overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);
                                                            startActivity(main);
                                                            finish();
                                                            age.setText("");

//                                        startActivity(new Intent(getApplicationContext(),login.class));
                                                        }
                                                        else
                                                        {
                                                            Toast.makeText(register.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                                        }

                                                    }
                                                });
                                            }
                                        }
                                    });

                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(register.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });


            }
        }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(register.this, email.class);
        startActivity(main);
        finish();

    }

}