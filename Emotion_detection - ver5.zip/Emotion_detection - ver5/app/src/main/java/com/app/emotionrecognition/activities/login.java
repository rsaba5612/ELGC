package com.app.emotionrecognition.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.app.emotionrecognition.R;


public class login extends AppCompatActivity {
    boolean doubleBackToExitPressedOnce = false;

    Button btnLog;
    EditText email, password;
    private TextView textsignup,restpass;
    ProgressBar loading;
    //    AwesomeValidation AW;
    private String user_name;
    private FirebaseAuth firebaseAuth;

    Spinner s11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loading = findViewById(R.id.progress);
        btnLog = findViewById(R.id.loginbtn);
        email = findViewById(R.id.textemail);
        password = findViewById(R.id.password);
        textsignup = findViewById(R.id.textsignup);
        restpass = findViewById(R.id.textforgetpass);


        firebaseAuth=FirebaseAuth.getInstance();


        btnLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ProgressDialog progressDialog = new ProgressDialog(login.this);
                progressDialog.setMessage("Please Wait..");

                progressDialog.show();

                String Email= email.getText().toString().trim();
                String Password=password.getText().toString().trim();

                if (Email.isEmpty()) {
                    email.setError(getString(R.string.input_error_email));
                    email.requestFocus();
                    progressDialog.dismiss();
                    return;
                }

                if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
                    email.setError(getString(R.string.input_error_email_invalid));
                    email.requestFocus();
                    progressDialog.dismiss();
                    return;
                }

                if (Password.isEmpty()) {
                    password.setError(getString(R.string.input_error_password));
                    password.requestFocus();
                    progressDialog.dismiss();
                    return;
                }

                if (Password.length() < 6) {
                    password.setError(getString(R.string.input_error_password_length));
                    password.requestFocus();
                    progressDialog.dismiss();
                    return;
                }

                firebaseAuth.signInWithEmailAndPassword(Email, Password)
                        .addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                progressDialog.dismiss();
                                if (task.isSuccessful()) {
                                    finish();
                                    Toast.makeText(login.this, "Login Success", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                                    if(firebaseAuth.getCurrentUser().isEmailVerified())
                                    {

                                    }
                                 /*   else
                                        {
                                            progressDialog.dismiss();
                                            Toast.makeText(login.this, "Please Verify your Email address", Toast.LENGTH_SHORT).show();
                                        }*/
                                    // Sign in success, update UI with the signed-in user's information
                                } else {
                                    progressDialog.dismiss();
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(login.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();

                                }

                                // ...
                            }
                        });
            }

        });

        textsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                Intent intent=new Intent(getApplicationContext(),firstname.class);
                overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);
                startActivity(intent);

            }
        });

      /*  restpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                finish();
                Intent intent=new Intent(getApplicationContext(),forget_password.class);
                overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);
                startActivity(intent);

            }
        });*/

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(firebaseAuth.getCurrentUser() != null && firebaseAuth.getCurrentUser().isEmailVerified())
        {
            finish();
            startActivity(new Intent(this,HomeActivity.class ));
        }
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
//        finish();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}

