package com.app.emotionrecognition.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.app.emotionrecognition.R;
import com.app.emotionrecognition.activities.HighScoreActivity;
import com.app.emotionrecognition.activities.MainQuizActivity;
import com.app.emotionrecognition.database.DatabaseHelper;
import com.app.emotionrecognition.database.Functions;
import com.app.emotionrecognition.database.QuestionItem;
import com.app.emotionrecognition.databinding.FragmentSkillBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;


public class SkillFragment extends Fragment {

    private FragmentSkillBinding binding;
    DatabaseHelper db;
    Functions functions = new Functions();
    private String offlineQuestionsJsonString;
    private static final int OFFLINE_DATA = 100;
    private ImageButton imgbtn;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentSkillBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        db = new DatabaseHelper(requireActivity());
        Typeface myTypeface = Typeface.createFromAsset(requireActivity().getAssets(), "fonts/IndieFlower.ttf");
        binding.quizTitleTextView.setTypeface(myTypeface);

        binding.highScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(requireActivity(), HighScoreActivity.class);
                startActivity(intent1);
               requireActivity(). overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);
            }
        });

        binding.startQuizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(requireActivity(), MainQuizActivity.class);
                startActivity(intent1);
                requireActivity(). overridePendingTransition(R.anim.slide_in_from_left_animation, R.anim.slide_out_from_right_animation);
            }
        });
        startOfflineMod();
        return root;
    }
    private void startOfflineMod() {
        try {
            if (db.doesDatabaseExist(requireActivity().getApplicationContext(), "quizDB")) {
                Log.w("DATABASE_STATE", "EXISTS");
                if (db.isQuestionsTableEmpty()) {
                    Log.w("DATABASE_STATE", "Empty");
                    offlineQuestionsJsonString = functions.jsonToStringFromAssetFolder("questions_data.json",requireActivity(). getApplicationContext());
                    loadingHandler.sendEmptyMessage(OFFLINE_DATA);
                }
            } else if (!db.doesDatabaseExist(requireActivity().getApplicationContext(), "quizDB")) {
                Log.w("DATABASE_STATE", "DOESN'T EXIST");
                offlineQuestionsJsonString = functions.jsonToStringFromAssetFolder("questions_data.json", requireActivity().getApplicationContext());
                loadingHandler.sendEmptyMessage(OFFLINE_DATA);
            }
        } catch (IOException e) {
            Log.e("IOException", String.valueOf(e));
        }
    }

    @SuppressLint("HandlerLeak")
    Handler loadingHandler = new Handler() {

        public void handleMessage(Message msg) {
            if (msg.what == OFFLINE_DATA) {
                try {
                    JSONObject offlineQuestionsJSON = new JSONObject(offlineQuestionsJsonString);
                    JSONArray questionsJsonArray = offlineQuestionsJSON.getJSONArray("data");
                    for (int i = 0; i < questionsJsonArray.length(); i++) {
                        JSONObject questionJsonObject = questionsJsonArray.getJSONObject(i);
                        QuestionItem questionItem = new QuestionItem();

                        questionItem.question = questionJsonObject.getString("question");
                        questionItem.level = questionJsonObject.getInt("level");
                        questionItem.answer = questionJsonObject.getString("answer");
                        questionItem.option1 = questionJsonObject.getString("option1");
                        questionItem.option2 = questionJsonObject.getString("option2");
                        questionItem.option3 = questionJsonObject.getString("option3");
                        questionItem.imageName = questionJsonObject.getString("image_name");

                        db.addQuestion(questionItem);
                    }

                } catch (JSONException e) {
                    Log.e("JSONException", String.valueOf(e));
                }
            }
        }
    };
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}